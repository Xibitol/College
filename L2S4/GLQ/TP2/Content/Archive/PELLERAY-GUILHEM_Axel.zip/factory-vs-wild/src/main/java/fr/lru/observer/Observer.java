package fr.lru.observer;

public interface Observer{
	
	// FUNCTIONS
	public void update(Observable observable, Object object);
}
