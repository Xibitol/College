package fr.lru.game;

import fr.lru.PrettyNamed;

public enum MonsterType implements PrettyNamed{

	DRAGON("Dragon"),
	GOLEM("Golem"),
	PHANTOM("Spectre"),
	ORC("Orc"),
	ZOMBIE("Mort_Vivant");

	private String displayName;

	private MonsterType(String displayName){
		this.displayName = displayName;
	}

	// GETTERS
	public static MonsterType fromDisplayName(String name){
		return PrettyNamed.fromDisplayName(MonsterType.class, name);
	}

	public String getDisplayName(){ return displayName; }
}
