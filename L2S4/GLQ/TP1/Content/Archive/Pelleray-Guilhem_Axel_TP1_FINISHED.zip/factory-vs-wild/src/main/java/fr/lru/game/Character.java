package fr.lru.game;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import fr.lru.observer.Event;

public class Character extends Entity{

	public static final String ENTITY_ID = "Personnage";

	private CharacterType type;
	private Collection<Skill> skills;

	public Character(String name, int health, int defense, int attack,
		CharacterType type, Collection<Skill> skills
	){
		super(name, health, defense, attack);

		this.type = type;
		this.skills = List.copyOf(skills);
	}

	// GETTERS
	public CharacterType getType(){ return type; }
	public Collection<Skill> getSkills(){
		return Collections.unmodifiableCollection(skills);
	}

	// FUNCTIONS
	@Override
	public void update(Event event){
		System.out.println("Character %s received %s event.".formatted(
			getName(), event.getClass().getSimpleName()
		));
	}
}
