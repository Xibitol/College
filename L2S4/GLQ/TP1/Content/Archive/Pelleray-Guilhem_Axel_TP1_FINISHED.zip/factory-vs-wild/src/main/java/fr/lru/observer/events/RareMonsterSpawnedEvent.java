package fr.lru.observer.events;

import fr.lru.observer.Event;

public class RareMonsterSpawnedEvent implements Event{}
