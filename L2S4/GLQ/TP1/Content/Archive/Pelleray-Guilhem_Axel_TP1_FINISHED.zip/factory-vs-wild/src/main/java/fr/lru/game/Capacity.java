package fr.lru.game;

import fr.lru.PrettyNamed;

public enum Capacity implements PrettyNamed{

	FIRE("Feu"),
	WATER("Eau"),
	LIGHT("Lumière"),
	DARKNESS("Ténèbres"),
	POISON("Poison"),
	ICE("Glace"),
	ENCHANTMENT("Magie"),
	COMBAT("Physique");

	private String displayName;

	private Capacity(String displayName){
		this.displayName = displayName;
	}

	// GETTERS
	public static Capacity fromDisplayName(String name){
		return PrettyNamed.fromDisplayName(Capacity.class, name);
	}

	public String getDisplayName(){ return displayName; }
}
