package fr.lru.observer;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public abstract class AbstractObservable implements Observable{

	private Map<Class<? extends Event>, Set<Observer>> observers
		= new HashMap<>();

	// SETTERS
	@Override
	public boolean addObserver(
		Class<? extends Event> type, Observer observer
	){
		observers.putIfAbsent(type, new HashSet<>());
		return observers.get(type).add(observer);
	}
	@Override
	public boolean removeObserver(
		Class<? extends Event> type, Observer observer
	){
		return observers.getOrDefault(type, Set.of()).remove(observer);
	}

	// FUNCTIONS
	protected void fire(Event event){
		observers.getOrDefault(event.getClass(), Set.of())
			.forEach(o -> o.update(event));
	}
}
