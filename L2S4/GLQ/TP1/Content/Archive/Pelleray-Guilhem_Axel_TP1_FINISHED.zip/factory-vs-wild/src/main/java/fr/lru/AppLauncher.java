package fr.lru;

import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import fr.lru.factory.EntityFactory;
import fr.lru.game.Character;
import fr.lru.game.Entity;
import fr.lru.game.Monster;
import fr.lru.game.GameEventManager;
import fr.lru.observer.events.DayNightChangedEvent;
import fr.lru.observer.events.LegendaryChestFoundEvent;
import fr.lru.observer.events.MagicalStormAppearedEvent;

public class AppLauncher{

	public static void main(String[] args){
		GameEventManager gem = new GameEventManager();
		Collection<Entity> entities = Collections.emptyList();

		try{
			entities = EntityFactory.get().fromResource(
				"characters_and_monsters.txt"
			);
		}catch(IOException e){
			e.printStackTrace();
		}

		entities.forEach(e -> {
			switch(e){
				case Character c -> gem.addObserver(
					MagicalStormAppearedEvent.class, c
				);
				case Monster m -> gem.addObserver(
					LegendaryChestFoundEvent.class, m
				);
				default -> {}
			}

			gem.addObserver(DayNightChangedEvent.class, e);
		});

		gem.start();

		ScheduledExecutorService ses = new ScheduledThreadPoolExecutor(1);
		ses.schedule(() -> {
			gem.stop();
		}, 10, TimeUnit.SECONDS);
		ses.close();
	}
}