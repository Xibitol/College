package fr.lru.observer;

public interface Observable{

	// SETTERS
	abstract boolean addObserver(
		Class<? extends Event> type, Observer observer
	);
	abstract boolean removeObserver(
		Class<? extends Event> type, Observer observer
	);
}
