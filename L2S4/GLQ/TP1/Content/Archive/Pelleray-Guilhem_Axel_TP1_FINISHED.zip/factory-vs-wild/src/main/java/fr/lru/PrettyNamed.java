package fr.lru;

public interface PrettyNamed{
	
	// GETTERS
	static <E extends PrettyNamed> E fromDisplayName(
		Class<E> type, String name
	){
		if(!type.isEnum()) throw new IllegalArgumentException();
		E[] values = type.getEnumConstants();
		int i = 0;

		while(i < values.length && !values[i].getDisplayName().equals(name))
			i++;

		if(i < values.length) return values[i];
		else
			throw new EnumConstantNotPresentException(
				type.asSubclass(Enum.class),
				String.format("{displayName=\"%s\"}", name)
			);
	}

	abstract String getDisplayName();
}