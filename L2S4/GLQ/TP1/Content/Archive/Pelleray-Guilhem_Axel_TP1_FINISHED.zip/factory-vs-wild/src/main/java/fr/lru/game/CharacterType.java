package fr.lru.game;

import fr.lru.PrettyNamed;

public enum CharacterType implements PrettyNamed{

	ARCHER("Archer"),
	KNIGHT("Guerrier"),
	MAGE("Mage");

	private String displayName;

	private CharacterType(String displayName){
		this.displayName = displayName;
	}

	// GETTERS
	public static CharacterType fromDisplayName(String name){
		return PrettyNamed.fromDisplayName(CharacterType.class, name);
	}

	public String getDisplayName(){ return displayName; }
}