package fr.lru.observer;

public interface Observer{

	// FUNCTIONS
	abstract void update(Event event);
}
