package fr.lru.game;

import fr.lru.PrettyNamed;

public enum Skill implements PrettyNamed{

	FIRE_BALL("Boule de feu (Dégâts en zone)"),
	INVOCATION("Invocation d'esprit (Invoque une créature alliée)"),
	PIERCING_SHOT("Tir perçant (Ignore l'armure)"),
	SHIELD_HIT("Coup de bouclier (Étourdit l'ennemi)");

	private String displayName;

	private Skill(String displayName){
		this.displayName = displayName;
	}

	// GETTERS
	public static Skill fromDisplayName(String name){
		return PrettyNamed.fromDisplayName(Skill.class, name);
	}

	public String getDisplayName(){ return displayName; }
}
