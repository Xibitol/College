package fr.lru.game;

import fr.lru.observer.Event;

public class Monster extends Entity{

	public static final String ENTITY_ID = "Monstre";

	private MonsterType type;
	private Capacity resistance;
	private Capacity weakness;

	public Monster(String name, int health, int defense, int attack,
	MonsterType type, Capacity resistance, Capacity weakness
	){
		super(name, health, defense, attack);

		this.type = type;
		this.resistance = resistance;
		this.weakness = weakness;
	}

	// GETTERS
	public MonsterType getType(){ return type; }
	public Capacity getResistance(){ return resistance;}
	public Capacity getWeakness(){ return weakness;}

	// FUNCTIONS
	@Override
	public void update(Event event){
		System.out.println("Monster %s received %s event.".formatted(
			getName(), event.getClass().getSimpleName()
		));
	}
}
