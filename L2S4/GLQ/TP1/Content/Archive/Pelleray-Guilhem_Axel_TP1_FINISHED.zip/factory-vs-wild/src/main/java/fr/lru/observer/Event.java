package fr.lru.observer;

public interface Event{}
