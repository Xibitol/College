package fr.lru.game;

import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.SequencedSet;
import java.util.TreeSet;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import fr.lru.observer.AbstractObservable;
import fr.lru.observer.Event;
import fr.lru.observer.events.DayNightChangedEvent;
import fr.lru.observer.events.DemonicPortalAppearedEvent;
import fr.lru.observer.events.DragonSpawnedEvent;
import fr.lru.observer.events.LegendaryChestFoundEvent;
import fr.lru.observer.events.MagicalStormAppearedEvent;
import fr.lru.observer.events.RareMonsterSpawnedEvent;

public class GameEventManager extends AbstractObservable{

	private static final SequencedSet<Class<? extends Event>> eventClasses;

	private ScheduledExecutorService scheduler;

	static{
		eventClasses = new TreeSet<>(Comparator.comparing(
			Class::getName, String::compareTo
		));
		eventClasses.addAll(List.of(
			DayNightChangedEvent.class,
			DemonicPortalAppearedEvent.class,
			DragonSpawnedEvent.class,
			LegendaryChestFoundEvent.class,
			MagicalStormAppearedEvent.class,
			RareMonsterSpawnedEvent.class
		));
	}

	{
		scheduler = Executors.newScheduledThreadPool(1);
	}

	public GameEventManager(){}

	// FUNCTIONS
	public void start(){
		scheduler.scheduleWithFixedDelay(new ScheduledTask(),
			0, 1, TimeUnit.SECONDS
		);
	}
	public void stop(){
		scheduler.shutdown();
	}

	@Override
	protected void fire(Event event){
		System.out.println("* GameEventManager fired %s event".formatted(
			event.getClass().getName()
		));

		super.fire(event);
	}

	// INNER CLASSES
	private class ScheduledTask implements Runnable{

		private static final Random random = new Random();

		public void run(){
			Class<? extends Event> event = eventClasses.stream().toList()
				.get(random.nextInt(0, eventClasses.size()));

			try{
				fire(event.getConstructor().newInstance());
			}catch(ReflectiveOperationException ignored){}
		}
	}
}